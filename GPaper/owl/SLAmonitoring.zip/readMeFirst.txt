1) To run our SLA Monitoring API execute "RunMonitoringMain.bat"
2) To compile our SLA Monitoring API execute "compileMonitoringAPI.bat"
3) To compile SLAont actions (SWRL Built-ins) execute "compileSLAontActions.bat"
4) To create SLAOnt actions jar execute "createSLAontActionsJar.bat"