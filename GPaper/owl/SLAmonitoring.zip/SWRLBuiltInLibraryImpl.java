    /*
     * This is my Fun
     */

    
    package edu.stanford.smi.protegex.owl.swrl.bridge.builtins.slaont;
    
    import edu.stanford.smi.protegex.owl.swrl.bridge.*;
    import edu.stanford.smi.protegex.owl.swrl.bridge.builtins.*;
    import edu.stanford.smi.protegex.owl.swrl.bridge.exceptions.*;
  
    import org.apache.commons.lang.StringUtils;
   
    import java.util.*;
//    import java.util.regex.*;

    

    public class SWRLBuiltInLibraryImpl extends AbstractSWRLBuiltInLibrary
    {
      private static String SWRLBLibraryName = "SLAOntActions";
    
      private static String SWRLBPrefix = "slaont:";
    
      private static String SWRLB_DISSEMINATE_VIOLATION = SWRLBPrefix + "disseminateViolation";
      
	  private ArgumentFactory argumentFactory;
    
   public SWRLBuiltInLibraryImpl() 
      { 
        super(SWRLBLibraryName); 
    
        argumentFactory = ArgumentFactory.getFactory();
      } // SWRLBuiltInLibraryImpl
    
      public void reset() {}
     
      // Built-ins for comparison, defined in Section 8.1. of http://www.daml.org/2004/04/swrl/builtins.html.
    
	 public boolean disseminateViolation(List<BuiltInArgument> arguments) throws BuiltInException
      {
        
    
        SWRLBuiltInUtil.checkNumberOfArgumentsAtLeast(1, arguments.size());
		String message = "----> ViolationDetected in SLAOnt caused by values: ";
		for (int argumentNumber = 0; argumentNumber < arguments.size()-1; argumentNumber++) { // Exception thrown if argument is not a literal.
          message += SWRLBuiltInUtil.getArgumentAsString(argumentNumber, arguments)+" , ";
         }
		message += SWRLBuiltInUtil.getArgumentAsString(arguments.size()-1, arguments);
        System.out.println(message);
        return true;
      } // greaterThan

  
} // SWRLBuiltInLibraryImpl